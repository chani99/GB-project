App.directive('gbNoteList', function() { 
	
});
